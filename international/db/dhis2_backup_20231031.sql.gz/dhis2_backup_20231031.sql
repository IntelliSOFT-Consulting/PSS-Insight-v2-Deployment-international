pg_dump: error: too many command-line arguments (first is "dhis")
Try "pg_dump --help" for more information.
